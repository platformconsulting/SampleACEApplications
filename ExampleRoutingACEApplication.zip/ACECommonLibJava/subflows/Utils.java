package subflows;

public class Utils {
	public static String upper(String s){
		return s.toUpperCase();
	}
}
